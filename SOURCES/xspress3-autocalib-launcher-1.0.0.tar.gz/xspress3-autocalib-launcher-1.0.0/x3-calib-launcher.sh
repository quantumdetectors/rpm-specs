#!/bin/sh
firefox xspress3:5000 &
xspress3-autocalib.py 
